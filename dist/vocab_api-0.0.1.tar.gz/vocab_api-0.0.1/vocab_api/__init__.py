from vocab_api.hello import get_list,Word
